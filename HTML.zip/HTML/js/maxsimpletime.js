// JavaScript Document
var maxt;

function showTime() {
   maxt = setTimeout( "showTime()", 1000 );
   myDate = new Date();
   
   // Get time parts
   hours   = myDate.getHours();
   minutes = myDate.getMinutes();
   seconds = myDate.getSeconds();
   
   // Just to display the time in a nice format
   if (hours < 10)   hours   = "0" + hours;
   if (minutes < 10) minutes = "0" + minutes;
   if (seconds < 10) seconds = "0" + seconds;
   
   // Change the block content
   document.getElementById("maxtime").innerHTML = hours+":"+minutes+":"+seconds;
}