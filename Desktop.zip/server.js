const http = require('http');
const { parse } = require('querystring');
const fs = require('fs');
const reqURL = '/create';

const server = http.createServer(function (req, resp) {
    if (req.method === 'POST') {
        collectRequestData(req, result => {
            console.log(result);
			var tarea = result.tarea;
			console.log(tarea.split('\r\n'));
        });
    } else if (req.url === "/create") {
        fs.readFile("product.html", function (error, pgResp) {
            if (error) {
                resp.writeHead(404, { 'Content-Type': 'text/html' });
                resp.write('<h2>Contents you are looking are Not Found</h2>');
            } else {
                resp.writeHead(200, { 'Content-Type': 'text/html' });
                resp.write(pgResp);
            }
			resp.end();
        });
    } else {
        resp.writeHead(200, { 'Content-Type': 'text/html' });
        resp.write('<h1>Product Manaager</h1><br />To create product please enter : ' + reqURL);   
		resp.end();		
    }	
});

function collectRequestData(request, callback) {
    const FORM_URLENCODED = 'application/x-www-form-urlencoded';
    if(request.headers['content-type'] === FORM_URLENCODED) {
        let body = '';
        request.on('data', chunk => {
            body += chunk.toString();
        });
        request.on('end', () => {
            callback(parse(body));
        });
    }
    else {
        callback(null);
    }
}


server.listen(3000); 
console.log('Server Started listening on 3000');